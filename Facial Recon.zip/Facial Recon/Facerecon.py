import cv2
import face_recognition
import os
'''
image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/Carlos.jpeg")
face_locations = face_recognition.face_locations(image)

face_landmarks_list = face_recognition.face_landmarks(image)

#face_detection_cli

print(face_locations[0][0])

print(face_landmarks_list)

'''

'''

from PIL import Image, ImageDraw
import face_recognition

# Load the jpg file into a numpy array
image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/Carlos.jpeg")

# Find all facial features in all the faces in the image
face_landmarks_list = face_recognition.face_landmarks(image)

pil_image = Image.fromarray(image)
for face_landmarks in face_landmarks_list:
    d = ImageDraw.Draw(pil_image, 'RGBA')

    # Make the eyebrows into a nightmare
    d.polygon(face_landmarks['left_eyebrow'], fill=(68, 54, 39, 128))
    d.polygon(face_landmarks['right_eyebrow'], fill=(68, 54, 39, 128))
    d.line(face_landmarks['left_eyebrow'], fill=(68, 54, 39, 150), width=5)
    d.line(face_landmarks['right_eyebrow'], fill=(68, 54, 39, 150), width=5)

    # Gloss the lips
    d.polygon(face_landmarks['top_lip'], fill=(150, 0, 0, 128))
    d.polygon(face_landmarks['bottom_lip'], fill=(150, 0, 0, 128))
    d.line(face_landmarks['top_lip'], fill=(150, 0, 0, 64), width=8)
    d.line(face_landmarks['bottom_lip'], fill=(150, 0, 0, 64), width=8)

    # Sparkle the eyes
    d.polygon(face_landmarks['left_eye'], fill=(255, 255, 255, 30))
    d.polygon(face_landmarks['right_eye'], fill=(255, 255, 255, 30))

    # Apply some eyeliner
    d.line(face_landmarks['left_eye'] + [face_landmarks['left_eye'][0]], fill=(0, 0, 0, 110), width=6)
    d.line(face_landmarks['right_eye'] + [face_landmarks['right_eye'][0]], fill=(0, 0, 0, 110), width=6)

    pil_image.show()
'''
import face_recognition
import cv2
import numpy as np



# This is a demo of running face recognition on live video from your webcam. It's a little more complicated than the
# other example, but it includes some basic performance tweaks to make things run a lot faster:
#   1. Process each video frame at 1/4 resolution (though still display it at full resolution)
#   2. Only detect faces in every other frame of video.

# PLEASE NOTE: This example requires OpenCV (the `cv2` library) to be installed only to read from your webcam.
# OpenCV is *not* required to use the face_recognition library. It's only required if you want to run this
# specific demo. If you have trouble installing it, try any of the other demos that don't require it instead.

# Get a reference to webcam #0 (the default one)
video_capture = cv2.VideoCapture(0)

#codec = 0x47504A4D  # MJPG
#video_capture.set(cv2.CAP_PROP_FPS, 30.0)
#video_capture.set(cv2.CAP_PROP_FOURCC, codec)
video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

video_capture.set(cv2.CAP_PROP_BUFFERSIZE, 3)

faces_path = '/home/nx/Facial Recon/Faces/known/'

known_face_encodings = []
known_face_names = []

for img in os.listdir(faces_path):
    print(img)
    
    name = img[:-5]

    path = "/home/nx/Facial Recon/Faces/known/{}".format(img)
    new_image = face_recognition.load_image_file(path)
    new_image_encoding = face_recognition.face_encodings(new_image)[0]

    known_face_encodings.append(new_image_encoding)
    known_face_names.append(name)






# Load a sample picture and learn how to recognize it.
#carlos_image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/Carlos.jpeg")
#carlos_face_encoding = face_recognition.face_encodings(carlos_image)[0]

# Load a second sample picture and learn how to recognize it.
#sami_image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/Sami.jpeg")
#sami_face_encoding = face_recognition.face_encodings(sami_image)[0]

# Load a second sample picture and learn how to recognize it.
#reza_image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/Reza.jpeg")
#reza_face_encoding = face_recognition.face_encodings(reza_image)[0]

# Load a second sample picture and learn how to recognize it.
#barry_image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/#Barry_specialist.jpeg")
#barry_face_encoding = face_recognition.face_encodings(barry_image)[0]

# Load a second sample picture and learn how to recognize it.
#chosen_image = face_recognition.load_image_file("/home/nx/Facial Recon/Faces/known/The_choosen_one.jpeg")
#chosen_face_encoding = face_recognition.face_encodings(chosen_image)[0]

# Create arrays of known face encodings and their names
#known_face_encodings = [
#    carlos_face_encoding,
#    sami_face_encoding,
#    reza_face_encoding,
#    barry_face_encoding,
#    chosen_face_encoding
#]
#known_face_names = [
#    "Carlos",
#    "Sami",
#    "Reza",
#    "Barry",
#    "The chosen one"
#]

# Initialize some variables
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True
img_counter = 0

while True:
    # Grab a single frame of video
    ret, frame = video_capture.read()

    #if not ret:
    #    print("failed to grab frame")
    #    break


    # Resize frame of video to 1/4 size for faster face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
    rgb_small_frame = small_frame[:, :, ::-1]


   



    # Only process every other frame of video to save time
    if process_this_frame:
        # Find all the faces and face encodings in the current frame of video
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        #face_landmarks_list = face_recognition.face_landmarks#(rgb_small_frame)

        face_names = []
        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"

            # # If a match was found in known_face_encodings, just use the first one.
            # if True in matches:
            #     first_match_index = matches.index(True)
            #     name = known_face_names[first_match_index]

            # Or instead, use the known face with the smallest distance to the new face
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            face_names.append(name)

    process_this_frame = not process_this_frame

    
    #cv2.imshow("test", rgb_small_frame)
    #print(face_locations)

    k = cv2.waitKey(1)
    if k%256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
    elif (k%256 == 32) & (face_locations != []):
        # SPACE pressed

        top = face_locations[0][0]      *4
        right = face_locations[0][1]    *4
        bottom = face_locations[0][2]   *4
        left = face_locations[0][3]     *4


        cropped = frame[top:bottom, left:right]

        name = input("Enter your name: ")
        path = '/home/nx/Facial Recon/Faces/known/'

        #img_name = "opencv_frame_{}.png".format(img_counter)
        img_name = "{}.jpeg".format(name)

        if os.path.exists(os.path.join(path, img_name)):
            print("Person already exists!")
            
        else:
            cv2.imwrite(os.path.join(path, img_name), cropped)
            print("{} written!".format(img_name))
            img_counter += 1

            path = "/home/nx/Facial Recon/Faces/known/{}.jpeg".format(name)
            new_image = face_recognition.load_image_file(path)
            new_image_encoding = face_recognition.face_encodings(new_image)[0]

            print("encoding: ", new_image_encoding)

            known_face_encodings.append(new_image_encoding)
            known_face_names.append(name)

    elif (k%256 == 32) & (face_locations == []):
        print("No ghosts allowed!")



    # Display the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up face locations since the frame we detected in was scaled to 1/4 size
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # Draw a box around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Draw a label with a name below the face
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

        
        #for face_landmarks in face_landmarks_list:

            # Let's trace out each facial feature in the image with a line!
        #    for facial_feature in face_landmarks.keys():
                
        #        for index in range(len(face_landmarks[facial_feature])-1):

        #            start = tuple([4*x for x in face_landmarks[facial_feature][index]])
        #            end = tuple([4*x for x in face_landmarks[facial_feature][index+1]])

                    #start = face_landmarks[facial_feature][index]
                    #end = face_landmarks[facial_feature][index+1]

                    #print(start)
                    #print(type(start))

        #            cv2.line(frame, start, end, (255, 255, 255))




    # Display the resulting image
    cv2.imshow('Video', frame)

    # Hit 'q' on the keyboard to quit!
    #if cv2.waitKey(1) & 0xFF == ord('q'):
    #    break

# Release handle to the webcam
video_capture.release()
cv2.destroyAllWindows()